<?php
	require_once(plugin_dir_path(__FILE__).'buttons.php');
	require_once(plugin_dir_path(__FILE__).'gallery-box.php');
	require_once(plugin_dir_path(__FILE__).'team-builder.php');
	require_once(plugin_dir_path(__FILE__).'lists.php');
	require_once(plugin_dir_path(__FILE__).'qoutes.php');
	require_once(plugin_dir_path(__FILE__).'spacers.php');
	require_once(plugin_dir_path(__FILE__).'caption.php');
	require_once(plugin_dir_path(__FILE__).'alert.php');
	require_once(plugin_dir_path(__FILE__).'paragraph.php');
	require_once(plugin_dir_path(__FILE__).'video.php');
	require_once(plugin_dir_path(__FILE__).'marker.php');
	require_once(plugin_dir_path(__FILE__).'accordion.php');
	require_once(plugin_dir_path(__FILE__).'toggles.php');
	require_once(plugin_dir_path(__FILE__).'social.php');




?>