<?php
add_shortcode('ot-gallery', 'gallery_handler');
function gallery_handler($atts, $content=null, $code="") {
	if(isset($atts['url'])) {
		if(substr($atts['url'],-1) == '/') {
			$atts['url'] = substr($atts['url'],0,-1);
		}
		$vars = explode('/',$atts['url']);
		$slug = $vars[count($vars)-1];
		$page = get_page_by_path($slug,'OBJECT',OT_POST_GALLERY);
		if(is_object($page)) {
			$id = $page->ID;
			if(is_numeric($id)) {
				$gallery_style = get_post_meta ( $id, "_".THEME_NAME."_gallery_style", true );
				$galleryImages = get_post_meta ( $id, THEME_NAME."_gallery_images", true ); 
				$imageIDs = explode(",",$galleryImages);
				$count = count($imageIDs);
				if($gallery_style=="lightbox") { $classL = 'light-show '; } else { $classL = false; }

				$content.=	'<div class="gallery-preview">';
					$content.=	'<a href="#gallery-left" class="gallery-preview-control icon-text"><i class="fa fa-angle-left"></i></a>';
					$content.=	'<a href="#gallery-right" class="gallery-preview-control icon-text"><i class="fa fa-angle-right"></i></a>';
					$content.=	'<div class="gallery-thumbs">';
						$content.=	'<div class="gallery-header">';
							$content.=	'<a href="'.$atts['url'].'" class="gallery-title">'.$page->post_title.'</a>';
							$content.=	'<a href="'.$atts['url'].'" class="gallery-count"><span class="icon-text"><i class="fa fa-camera"></i></span>'.OT_image_count($id).' '.__("photos",'legatus-theme').'</a>';
						$content.=	'</div>';
						$content.=	'<ul>';
						$counter = 1;
	            		foreach($imageIDs as $imgID) { 
	            			if ($counter==7) break;
	            			if($imgID) {
		            			$file = wp_get_attachment_url($imgID);
		            			$image = get_post_thumb(false, 57, 57, false, $file);
								if($counter==1) { $class=' class="active"'; } else { $class=false; }				
								$content.=	'<li'.$class.'><img src="'.$image['src'].'" class="setborder" alt="'.esc_attr($page->post_title).'" title="'.esc_attr($page->post_title).'" /></li>';
								$counter++;
							}
						} 
					$content.=	'</ul>';
					$content.=	'</div>';
					$content.=	'<ul class="full-size">';
					$counter = 1;
	            		foreach($imageIDs as $imgID) { 
	            			if ($counter==7) break;
	            			if($imgID) {
		            			$file = wp_get_attachment_url($imgID);
		            			$image = get_post_thumb(false, 680, 418, false, $file);
								if($counter==1) { $class=' class="active"'; } else { $class=false; }				
								$content.=	'<li'.$class.'><img src="'.$image['src'].'" class="setborder" alt="'.esc_attr($page->post_title).'" title="'.esc_attr($page->post_title).'" /></li>';
								$counter++;
							}
						} 
					$content.=	'</ul>';
				$content.=	'</div>';
			} else {
				$content.= "Incorrect URL attribute defined";
			}
		} else {
			$content.= "Incorrect URL attribute defined";
		}
		
	} else {
		$content.= "No url attribute defined!";
	
	}
	return $content;
}


?>