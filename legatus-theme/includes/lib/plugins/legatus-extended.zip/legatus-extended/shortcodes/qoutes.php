<?php
	add_shortcode('blockquote', 'blockquote_handler');

	function blockquote_handler($atts, $content=null, $code="") {

		$return =  '<div class="quote-'.$atts['style'].'">';
			$return.=  '<blockquote>';
				$return.=  $content;
			$return.=  '</blockquote>';
		$return.=  '</div>';

		return $return;
	}
?>
