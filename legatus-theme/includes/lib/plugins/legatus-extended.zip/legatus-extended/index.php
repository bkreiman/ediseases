<?php
	/*
	Plugin Name: 	Legatus Extended
	Plugin URI: 	http://www.orange-themes.com/
	Description: 	Legatus shortcodes & galleries
	Version: 		1.0.0
	Author: 		Orange Themes
	Author URI: 	http://www.orange-themes.com/
	Domain Path:    /languages
	Text Domain:	legatus-theme
	License:		GPL-2.0+
	License URI:	http://www.gnu.org/licenses/gpl-2.0.txt
	*/

function legatus_extended() {
	return true;
}

require_once( plugin_dir_path(__FILE__).'aweber_api/aweber_api.php' );
require_once( plugin_dir_path(__FILE__).'widgets/widget-aweber.php' );
require_once( plugin_dir_path(__FILE__).'shortcodes/init.php' );

add_action('init', 'create_gallery');

if (!defined('OT_POST_GALLERY')) {
	//POST TYPES
	define("OT_POST_GALLERY","gallery");	
}

function create_gallery() {
		
	$labels = array(
    'name' => _x('Gallery', 'legatus menu', 'legatus-theme'),
    'singular_name' => _x('Gallery Menu', 'legatus menu', 'legatus-theme'),
    'add_new' => _x('Add New', 'legatus menu', 'legatus-theme'),
    'add_new_item' => esc_html__('Add New Item','legatus-theme'),
    'edit_item' => esc_html__('Edit Item','legatus-theme'),
    'new_item' => esc_html__('New Gallery Item','legatus-theme'),
    'view_item' => esc_html__('View Item','legatus-theme'),
    'search_items' => esc_html__('Search Gallery Items','legatus-theme'),
    'not_found' =>  esc_html__('No gallery items found','legatus-theme'),
    'not_found_in_trash' => esc_html__('No gallery items found in Trash','legatus-theme'), 
    'parent_item_colon' => ''
	);
  
	register_taxonomy(OT_POST_GALLERY."-cat", 
					    	array("Gallery Categories"), 
					    	array(	"hierarchical" => true, 
					    			"label" => "Gallery Categories", 
					    			"singular_label" => "Gallery Categories", 
					    			"rewrite" => true,
					    			"query_var" => true
					    		));  
		
		register_post_type( OT_POST_GALLERY,
		array( 'labels' => $labels,
	         'public' => true,  
	         'show_ui' => true,  
	         'capability_type' => 'post',  
	         'hierarchical' => false,  
			 'taxonomies' => array(OT_POST_GALLERY.'-cat'),
	         'supports' => array('title', 'editor', 'thumbnail', 'comments', 'page-attributes', 'excerpt') ) );

}